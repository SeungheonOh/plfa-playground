module plfa.String where

open import Agda.Builtin.Char using (Char; primCharToNat)
open import Agda.Builtin.Char.Properties using (primCharToNatInjective)
open import Agda.Builtin.Equality using (_≡_; refl)
open import Agda.Builtin.List using (List; []; _∷_)
open import Agda.Builtin.Nat using (Nat; zero; suc)
open import Agda.Builtin.String public using (String)
open import Agda.Builtin.String as String using (primStringToList)
open import Agda.Builtin.String.Properties using (primStringToListInjective)
open import Relation.Nullary using (Dec; yes; no)

cong : ∀ {A B : Set} (f : A → B) {x y} → x ≡ y → f x ≡ f y
cong f refl = refl

nat-eq? : ∀ (x y : Nat) → Dec (x ≡ y)
nat-eq? zero zero = yes refl
nat-eq? zero (suc y) = no (λ ())
nat-eq? (suc x) zero = no (λ ())
nat-eq? (suc x) (suc y) with nat-eq? x y
... | yes refl = yes refl
... | no x≢y = no λ { refl → x≢y refl }

char-eq? : ∀ (x y : Char) → Dec (x ≡ y)
char-eq? x y with nat-eq? (primCharToNat x) (primCharToNat y)
... | yes p = yes (primCharToNatInjective x y p)
... | no p = no λ q → p (cong primCharToNat q)

list-eq? : ∀ (xs ys : List Char) → Dec (xs ≡ ys)
list-eq? [] [] = yes refl
list-eq? [] (y ∷ ys) = no (λ ())
list-eq? (x ∷ xs) [] = no (λ ())
list-eq? (x ∷ xs) (y ∷ ys) with char-eq? x y | list-eq? xs ys
... | yes refl | yes refl = yes refl
... | no x≢y | _ = no λ { refl → x≢y refl }
... | _ | no xs≢ys = no λ { refl → xs≢ys refl }

infix 4 _≟_
_≟_ : ∀ (x y : String) → Dec (x ≡ y)
x ≟ y with list-eq? (primStringToList x) (primStringToList y)
... | yes p = yes (primStringToListInjective x y p)
... | no p = no λ q → p (cong primStringToList q)
