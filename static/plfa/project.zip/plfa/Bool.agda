module plfa.Bool where
open import Data.Bool.Base public
