module plfa.Product where
open import Data.Product.Base public
