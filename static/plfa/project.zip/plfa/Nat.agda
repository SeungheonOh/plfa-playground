module plfa.Nat where
open import Agda.Builtin.Nat public
  using (zero; suc; _+_; _*_)
  renaming (Nat to ℕ; _-_ to _∸_)

infixr 8 _^_
_^_ : ℕ → ℕ → ℕ
m ^ zero  = 1
m ^ suc n = m * (m ^ n)

infix 4 _≤_ _<_
data _≤_ : ℕ → ℕ → Set where
  z≤n : ∀ {n} → zero ≤ n
  s≤s : ∀ {m n} → m ≤ n → suc m ≤ suc n

_<_ : ℕ → ℕ → Set
m < n = suc m ≤ n

pattern z<s {n} = s≤s (z≤n {n})
pattern s<s {m} {n} m<n = s≤s {m} {n} m<n

open import Relation.Nullary using (Dec; yes; no)

infix 4 _≤?_
_≤?_ : ∀ m n → Dec (m ≤ n)
zero  ≤? n     = yes z≤n
suc m ≤? zero  = no (λ ())
suc m ≤? suc n with m ≤? n
... | yes m≤n = yes (s≤s m≤n)
... | no  m≰n = no λ { (s≤s m≤n) → m≰n m≤n }
