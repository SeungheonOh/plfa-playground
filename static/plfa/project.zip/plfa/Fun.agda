module plfa.Fun where
open import Function.Base public
