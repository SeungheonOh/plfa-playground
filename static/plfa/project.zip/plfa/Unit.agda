module plfa.Unit where
open import Data.Unit.Base public
