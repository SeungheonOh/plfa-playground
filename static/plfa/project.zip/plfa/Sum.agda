module plfa.Sum where
open import Data.Sum.Base public
