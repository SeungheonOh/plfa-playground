module plfa.browser.EqualityCore where
open import Relation.Binary.PropositionalEquality.Core public
