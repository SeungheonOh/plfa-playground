module plfa.NatProps where

open import Agda.Builtin.Nat using (Nat; zero; suc; _+_; _*_)
open import Agda.Builtin.Equality using (_≡_; refl)

sym : ∀ {A : Set} {x y : A} → x ≡ y → y ≡ x
sym refl = refl

cong : ∀ {A B : Set} (f : A → B) {x y} → x ≡ y → f x ≡ f y
cong f refl = refl

+-suc : ∀ m n → m + suc n ≡ suc (m + n)
+-suc zero n = refl
+-suc (suc m) n = cong suc (+-suc m n)

+-assoc : ∀ m n o → (m + n) + o ≡ m + (n + o)
+-assoc zero n o = refl
+-assoc (suc m) n o = cong suc (+-assoc m n o)

+-identityˡ : ∀ n → zero + n ≡ n
+-identityˡ n = refl

+-identityʳ : ∀ n → n + zero ≡ n
+-identityʳ zero = refl
+-identityʳ (suc n) = cong suc (+-identityʳ n)

+-comm : ∀ m n → m + n ≡ n + m
+-comm zero n = sym (+-identityʳ n)
+-comm (suc m) n rewrite +-comm m n | sym (+-suc n m) = refl

*-zeroʳ : ∀ n → n * zero ≡ zero
*-zeroʳ zero = refl
*-zeroʳ (suc n) = *-zeroʳ n

*-suc : ∀ m n → m * suc n ≡ m + m * n
*-suc zero n = refl
*-suc (suc m) n
  rewrite *-suc m n
        | sym (+-assoc n m (m * n))
        | +-comm n m
        | +-assoc m n (m * n)
  = refl

*-identityˡ : ∀ n → 1 * n ≡ n
*-identityˡ n = +-identityʳ n

*-identityʳ : ∀ n → n * 1 ≡ n
*-identityʳ zero = refl
*-identityʳ (suc n) = cong suc (*-identityʳ n)

*-comm : ∀ m n → m * n ≡ n * m
*-comm zero n = sym (*-zeroʳ n)
*-comm (suc m) n rewrite *-comm m n | sym (*-suc n m) = refl

*-distribʳ-+ : ∀ m n o → (n + o) * m ≡ n * m + o * m
*-distribʳ-+ m zero o = refl
*-distribʳ-+ m (suc n) o
  rewrite *-distribʳ-+ m n o
        | sym (+-assoc m (n * m) (o * m))
  = refl

*-assoc : ∀ m n o → (m * n) * o ≡ m * (n * o)
*-assoc zero n o = refl
*-assoc (suc m) n o
  rewrite *-distribʳ-+ o n (m * n)
        | *-assoc m n o
  = refl
